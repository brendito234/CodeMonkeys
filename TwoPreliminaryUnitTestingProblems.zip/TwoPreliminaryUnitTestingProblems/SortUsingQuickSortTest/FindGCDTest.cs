﻿using TwoPreliminaryUnitTestingProblems;

namespace MethodsTests
{
    internal class Tests
    {
        //Тест, който осигурява правилното поведение на метода в случай на валидни аргумнети
        [Test]
        //arrange
        [TestCase(54, 24, 6)] // Обикновен случай
        [TestCase(17, 13, 1)] // Случай с две естествени числа
        [TestCase(10, 0, 10)] // Случай с една нула (Гранична стойност)
        [TestCase(5, 5, 5)] // Случай с две еднакви числа
        [TestCase(123456789, 987654321, 9)] // Случай с две големи числа
        [TestCase(-54, -24, 6)] // Случай с две отрицателни числа (Гранични стойности)
        [TestCase(0, 0, 0)] // Случай с две нули (Гранични стойности)
        public void PositiveTest(int a, int b, int target)
        {
            //act
            int gcd = FindGCD.GCD(a, b);

            //assert
            Assert.That(target, Is.EqualTo(gcd));
        }
    }
}

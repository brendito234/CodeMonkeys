﻿namespace TwoPreliminaryUnitTestingProblems
{

    public static class SortUsingQuickSort
    {
        public static void QuickSort(int[] array, int left, int right) 
        {
            if (left < 0)
                throw new ArgumentException("Left boundary cannot be smaller than 0.");
            if (right > array.Length - 1)
                throw new ArgumentException("Right boundary cannot exceed the Length of the array minus one.");
            if (left < right)
            {
                int pivotIndex = Partition(array, left, right);

                QuickSort(array, left, pivotIndex - 1);
                QuickSort(array, pivotIndex + 1, right);
            }
        }
        public static int Partition(int[] array, int left, int right)
        {
            int pivot = array[right];
            int LessThanPivot = left - 1;

            for (int i = left; i < right; i++)
            {
                if (array[i] < pivot)
                {
                    LessThanPivot++;
                    Swap(array, LessThanPivot, i);
                }
            }

            LessThanPivot++;
            Swap(array, LessThanPivot, right);
            return LessThanPivot;
        }
        public static void Swap(int[] array, int firstIndex, int secondIndex)
        {
            int temporary = array[firstIndex];
            array[firstIndex] = array[secondIndex];
            array[secondIndex] = temporary;
        }
    }
    public class FindGCD
    {
        public static int GCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return Math.Abs(a);
        }
    }
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine();
        }
    }
}
